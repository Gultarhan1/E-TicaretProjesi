﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ECommerceApp.DomainLayer.Enums
{
    public enum Status { Active = 1, Modified = 2, Passive = 3 }
}
