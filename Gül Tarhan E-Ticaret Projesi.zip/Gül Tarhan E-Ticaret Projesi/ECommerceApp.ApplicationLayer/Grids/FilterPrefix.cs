﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ECommerceApp.ApplicationLayer.Grids
{
    public class FilterPrefix
    {
        public const string Category = "category-";
        public const string UnitPrice = "price-";
        public const string AppUser = "seller-";
    }
}
